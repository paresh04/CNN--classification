clc;
clear all;
close all;
finalImage;
%a = imread('lena.jpg');
% load('C:\Users\hp\Downloads\brainTumorDataPublic_1766\2.mat')
%r = zeros(512,512);
%an = cjdata.image;
% a = double(finalImage);
% a = a * 0.0005;
% subplot(2,2,1);
imshow(finalImageCopy);
% title('Original Image');
% %Using functions
% hf = imhist(a);
% subplot(2,2,2);
% bar(hf);
% title('Histogram of Original Image');
% 
% hf1 = histeq(a);
% subplot(2,2,3);
% imshow(hf1);
% title('Histogram Equivalent of Image');
% 
% hf2 = imhist(hf1);
% subplot(2,2,4);
% bar(hf2);
% title('Histogram of Equivalent of Image');